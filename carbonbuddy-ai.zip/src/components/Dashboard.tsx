import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, AreaChart, Area, CartesianGrid, Sector } from 'recharts';
import { CarbonResults } from '../types';
import { TreeDeciduous, Car, Zap, Info, TrendingDown, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { ActionCard } from './ActionCard';

interface Props {
  results: CarbonResults;
}

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent } = props;

  return (
    <g>
      <text x={cx} y={cy} dy={-10} textAnchor="middle" fill={fill} className="font-bold font-display text-lg">
        {payload.category}
      </text>
      <text x={cx} y={cy} dy={20} textAnchor="middle" fill="#64748b" className="font-bold text-xs">
        {(percent * 100).toFixed(0)}%
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 8}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 12}
        outerRadius={outerRadius + 15}
        fill={fill}
      />
    </g>
  );
};

export default function Dashboard({ results }: Props) {
  const [activeIndex, setActiveIndex] = React.useState(0);
  const COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#64748b'];

  const totalRecSavings = results.topActions.reduce((acc, curr) => acc + curr.co2Saved, 0);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };
  
  // Potential Path Data
  const projectionData = [
    { name: 'Today', emissions: results.totalEmissions },
    { name: '+3mo', emissions: results.totalEmissions - (totalRecSavings * 0.25) },
    { name: '+6mo', emissions: results.totalEmissions - (totalRecSavings * 0.5) },
    { name: '+9mo', emissions: results.totalEmissions - (totalRecSavings * 0.75) },
    { name: 'Target', emissions: results.totalEmissions - totalRecSavings },
  ];

  return (
    <div className="space-y-6 md:space-y-10 pb-12">
      {/* Hero Stats Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="lg:col-span-2 bg-slate-900 rounded-3xl md:rounded-[2.5rem] p-6 md:p-10 text-white relative overflow-hidden lg:flex lg:gap-10 min-h-[350px] md:min-h-[400px]"
        >
          <div className="relative z-10 flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4 md:mb-6">
                <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
                  <Sparkles size={18} className="md:w-5 md:h-5" />
                </div>
                <span className="text-[10px] md:text-sm font-bold uppercase tracking-widest text-slate-400">AI Sustainability Profile</span>
              </div>
              
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold font-display leading-tight md:leading-[1.1] mb-6 md:mb-8">
                Your path to <span className="text-emerald-500">Net Zero</span> starts here.
              </h1>
              
              <div className="p-4 md:p-6 bg-white/5 border border-white/10 rounded-2xl md:rounded-3xl backdrop-blur-md lg:max-w-none">
                <p className="text-sm md:text-lg text-slate-300 italic leading-relaxed">
                  "{results.aiInsight}"
                </p>
              </div>
            </div>

            <div className="flex items-center gap-8 md:gap-12 mt-8 md:mt-12 lg:mt-6">
              <div className="group cursor-help">
                <div className="text-emerald-500 text-3xl md:text-5xl font-bold font-display flex items-center gap-2">
                  <span className="opacity-50 text-2xl">🔥</span> {results.totalEmissions.toLocaleString()}
                </div>
                <div className="text-slate-500 text-[11px] md:text-xs font-bold uppercase tracking-wider mt-1">Current kg CO2/yr</div>
              </div>
              <div className="w-px h-10 md:h-12 bg-slate-800" />
              <div className="group cursor-help">
                <div className="text-white text-3xl md:text-5xl font-bold font-display flex items-center gap-2">
                  <span className="opacity-50 text-2xl">🎯</span> {Math.round(results.totalEmissions - totalRecSavings).toLocaleString()}
                </div>
                <div className="text-slate-500 text-[11px] md:text-xs font-bold uppercase tracking-wider mt-1">Potential Target</div>
              </div>
            </div>
          </div>

          <div className="hidden lg:flex flex-col items-end justify-center w-64 shrink-0 relative z-10">
             <div className="text-right space-y-4">
                <div className="text-emerald-500/40 text-7xl font-display font-black leading-none select-none">
                  {Math.round((totalRecSavings / results.totalEmissions) * 100)}%
                </div>
                <div className="text-xs font-bold uppercase tracking-[0.2em] text-slate-500">Reduction Potential</div>
             </div>
          </div>

          <div className="absolute -bottom-24 -right-24 w-64 h-64 md:w-96 md:h-96 bg-emerald-500/20 rounded-full blur-[120px]" />
          <div className="absolute top-10 -right-10 w-48 h-48 bg-blue-500/10 rounded-full blur-[80px]" />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl md:rounded-[2.5rem] border border-slate-100 p-6 md:p-10 shadow-sm flex flex-col items-center justify-between text-center min-h-[400px]"
        >
          <div className="w-full">
            <h3 className="text-base md:text-lg font-bold text-slate-900 font-display mb-1">Impact Distribution</h3>
            <p className="text-[10px] text-slate-400 font-medium uppercase tracking-widest mb-6">Where your carbon comes from</p>
          </div>

          <div className="relative w-full aspect-square max-w-[280px] md:max-w-[320px] mb-6">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  activeIndex={activeIndex}
                  activeShape={renderActiveShape}
                  data={results.breakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={95}
                  paddingAngle={6}
                  dataKey="value"
                  onMouseEnter={onPieEnter}
                  stroke="none"
                >
                  {results.breakdown.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-slate-900/90 backdrop-blur-xl text-white p-3 rounded-2xl border border-white/10 shadow-2xl">
                          <p className="text-[10px] font-bold uppercase tracking-widest text-emerald-400 mb-1">{payload[0].name}</p>
                          <p className="text-sm font-bold font-display">{payload[0].value.toLocaleString()} <span className="opacity-50 text-[10px]">kg CO2/yr</span></p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="grid grid-cols-2 gap-2 w-full">
            {results.breakdown.slice(0, 4).map((item, i) => (
              <div key={item.category} className="flex items-center gap-2 p-2 bg-slate-50 rounded-xl">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                <div className="flex flex-col items-start overflow-hidden">
                  <span className="text-[9px] text-slate-400 font-bold uppercase truncate w-full">{item.category}</span>
                  <span className="text-xs font-bold text-slate-700">{item.percentage.toFixed(0)}%</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      <section>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8 md:mb-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-6 md:w-8 h-[2px] bg-emerald-500" />
              <span className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-emerald-600">The High-Impact Directive</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 font-display">Your Top 3 Actions</h2>
            <p className="text-sm md:text-slate-500 mt-2">These three shifts represent 80% of your available impact.</p>
          </div>
          
          <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-full text-[10px] md:text-xs font-bold w-fit">
            <Zap size={14} className="fill-emerald-500" />
            Combined Potential: -{totalRecSavings.toLocaleString()} kg/yr
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {results.topActions.map((action, index) => (
            <ActionCard key={action.id} action={action} index={index} />
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 md:p-10 rounded-3xl md:rounded-[2.5rem] border border-slate-100 shadow-sm"
        >
          <div className="flex items-center justify-between mb-8 md:mb-10">
            <div>
              <h3 className="text-xl md:text-2xl font-bold text-slate-900 font-display">Strategic Projection</h3>
              <p className="text-xs md:text-sm text-slate-500">Emissions drop over 12 months</p>
            </div>
            <div className="p-2 md:p-3 bg-blue-50 text-blue-600 rounded-xl md:rounded-2xl">
              <TrendingDown size={20} className="md:w-6 md:h-6" />
            </div>
          </div>

          <div className="h-[250px] md:h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={projectionData}>
                <defs>
                  <linearGradient id="colorEmissions" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 600, fill: '#94a3b8' }} 
                  dy={10} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 600, fill: '#94a3b8' }} 
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  itemStyle={{ fontSize: '12px', fontWeight: 'bold', color: '#10b981' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="emissions" 
                  stroke="#10b981" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorEmissions)" 
                  name="CO2 Output"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-slate-50 p-6 md:p-10 rounded-3xl md:rounded-[2.5rem] border border-slate-100 flex flex-col"
        >
          <div className="flex items-center gap-3 mb-6 md:mb-8">
            <div className="p-2 md:p-3 bg-white rounded-xl md:rounded-2xl shadow-sm text-slate-900">
              <Info size={20} className="md:w-6 md:h-6" />
            </div>
            <h3 className="text-xl md:text-2xl font-bold text-slate-900 font-display">Contextual Mastery</h3>
          </div>

          <div className="space-y-4 md:space-y-6 flex-grow">
            {[
              { label: 'Trees Offset Equivalent', value: results.metrics.treesEquivalent, sub: 'Mature trees needed per year', icon: TreeDeciduous, emoji: '🌳' },
              { label: 'Unused Driving Power', value: results.metrics.drivingEquivalent, sub: 'Kilometers not driven', icon: Car, emoji: '🚗' },
              { label: 'Home Energy Equivalent', value: results.metrics.homeEnergyEquivalent, sub: 'Days of average home power', icon: Zap, emoji: '⚡' },
            ].map((m, i) => (
              <div key={i} className="bg-white p-4 md:p-5 rounded-2xl md:rounded-3xl shadow-sm flex items-center gap-4 md:gap-5 hover:shadow-md hover:-translate-y-1 transition-all">
                <div className="p-2 md:p-3 bg-slate-50 text-slate-400 rounded-lg md:rounded-xl text-xl md:text-2xl">
                  {m.emoji}
                </div>
                <div>
                  <div className="text-lg md:text-xl font-bold text-slate-900 font-display">{m.value.toLocaleString()}</div>
                  <div className="text-[10px] md:text-xs text-slate-500 font-medium">{m.label}</div>
                  <div className="text-[9px] md:text-[10px] text-slate-400 italic">{m.sub}</div>
                </div>
              </div>
            ))}
          </div>
          
          <button className="mt-8 md:mt-10 w-full py-4 bg-white border border-slate-200 text-slate-900 rounded-xl md:rounded-2xl font-bold text-sm hover:bg-slate-100 transition-colors active:scale-95 cursor-tree-hover">
            Download Impact Report (PDF)
          </button>
        </motion.div>
      </div>
    </div>
  );
}
