import React, { useState } from 'react';
import { FileUp, FileText, Loader2, CheckCircle2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface Props {
  onDataExtracted: (data: any) => void;
}

export default function DocumentScanner({ onDataExtracted }: Props) {
  const [isUploading, setIsUploading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setError(null);

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      try {
        const response = await fetch('/api/analyze-receipt', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: base64 })
        });
        const data = await response.json();
        onDataExtracted(data);
        setIsSuccess(true);
        setTimeout(() => setIsSuccess(false), 3000);
      } catch (err) {
        setError('Failed to analyze document. Please try again.');
      } finally {
        setIsUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm border-dashed border-2 hover:border-emerald-300 transition-colors">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
            <FileText size={20} />
          </div>
          <div>
            <h4 className="font-bold text-slate-900">Auto-Extract Emissions</h4>
            <p className="text-xs text-slate-500">Upload bills or fuel receipts</p>
          </div>
        </div>
      </div>

      <label className="relative flex flex-col items-center justify-center p-8 border-2 border-dashed border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-50 transition-all">
        <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} disabled={isUploading} />
        
        <AnimatePresence mode="wait">
          {isUploading ? (
            <motion.div 
              key="loading"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="flex flex-col items-center"
            >
              <Loader2 className="text-emerald-500 animate-spin mb-3" size={32} />
              <p className="text-sm font-medium text-slate-600">AI is analyzing document...</p>
            </motion.div>
          ) : isSuccess ? (
            <motion.div 
              key="success"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="flex flex-col items-center"
            >
              <CheckCircle2 className="text-emerald-500 mb-3" size={32} />
              <p className="text-sm font-medium text-emerald-600">Data Extracted Successfully!</p>
            </motion.div>
          ) : (
            <motion.div 
              key="idle"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="flex flex-col items-center"
            >
              <FileUp className="text-slate-300 mb-3" size={32} />
              <p className="text-sm font-medium text-slate-600">Drag & drop or <span className="text-emerald-600">browse</span></p>
              <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-bold">Max 5MB • JPG, PNG</p>
            </motion.div>
          )}
        </AnimatePresence>

        {error && (
          <div className="mt-4 flex items-center gap-2 text-xs text-red-500 font-medium">
            <X size={14} /> {error}
          </div>
        )}
      </label>
    </div>
  );
}
