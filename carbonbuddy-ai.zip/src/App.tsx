/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Leaf, Sparkles, RefreshCcw, Github, MessageSquare, X, Zap, ArrowRight, ShieldCheck, TrendingDown } from 'lucide-react';
import AssessmentForm from './components/AssessmentForm';
import Dashboard from './components/Dashboard';
import AICoach from './components/AICoach';
import DocumentScanner from './components/DocumentScanner';
import { AssessmentData, CarbonResults } from './types';
import { calculateFootprint } from './utils/calculations';
import { cn } from './lib/utils';

export default function App() {
  const [view, setView] = useState<'landing' | 'assessment' | 'results'>('landing');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<CarbonResults | null>(null);
  const [assessment, setAssessment] = useState<AssessmentData | null>(null);
  const [showCoach, setShowCoach] = useState(false);

  const [isInactive, setIsInactive] = useState(false);

  useEffect(() => {
    let timeout: NodeJS.Timeout;

    const resetTimer = () => {
      setIsInactive(false);
      clearTimeout(timeout);
      timeout = setTimeout(() => setIsInactive(true), 5 * 60 * 1000); // 5 minutes
    };

    const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart'];
    events.forEach(event => window.addEventListener(event, resetTimer));

    resetTimer();

    return () => {
      events.forEach(event => window.removeEventListener(event, resetTimer));
      clearTimeout(timeout);
    };
  }, []);

  const startAssessment = () => {
    setView('assessment');
    window.scrollTo(0, 0);
  };

  const handleAssessmentComplete = (data: AssessmentData) => {
    setIsLoading(true);
    window.scrollTo(0, 0);

    // Fake carbon-themed loading screen
    setTimeout(() => {
      const calcResults = calculateFootprint(data);
      setAssessment(data);
      setResults(calcResults);
      setIsLoading(false);
      setView('results');
    }, 2500);
  };

  const reset = () => {
    setView('landing');
    setResults(null);
    setAssessment(null);
    setShowCoach(false);
    window.scrollTo(0, 0);
  };

  return (
    <div className={cn(
      "min-h-screen flex flex-col font-sans transition-all duration-1000 selection:bg-emerald-200 selection:text-emerald-900",
      view === 'landing' ? "bg-white text-slate-900" : "bg-[#f8fafc] text-slate-900",
      isInactive ? "cursor-inactive" : ""
    )}>
      {/* Background Decorations */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className={cn(
          "absolute -top-48 -left-48 w-[40rem] h-[40rem] rounded-full blur-[120px] opacity-40 animate-pulse transition-colors duration-1000",
          view === 'landing' ? "bg-emerald-500/10" : "bg-emerald-100/40"
        )} />
        <div className={cn(
          "absolute top-1/4 right-0 w-[50rem] h-[50rem] rounded-full blur-[160px] opacity-30 transition-colors duration-1000",
          view === 'landing' ? "bg-blue-500/10" : "bg-blue-100/30"
        )} />
        <div className="absolute bottom-0 left-1/4 w-[60rem] h-[60rem] bg-emerald-50/60 rounded-full blur-[200px] opacity-50" />
        
        {/* Fill decorative blank space for large screens */}
        <div className="hidden lg:block absolute top-[20%] left-[5%] w-px h-[30%] bg-gradient-to-b from-transparent via-slate-200 to-transparent" />
        <div className="hidden lg:block absolute top-[15%] right-[8%] w-px h-[40%] bg-gradient-to-b from-transparent via-slate-200 to-transparent" />
        <div className="hidden xl:block absolute bottom-[10%] left-[15%] text-[8rem] font-display font-black text-slate-100/50 select-none -rotate-90 origin-left">
          NET ZERO
        </div>
      </div>

      {/* Navigation */}
      <nav className={cn(
        "fixed top-0 left-0 right-0 z-50 backdrop-blur-xl border-b transition-colors duration-500",
        view === 'landing' ? "bg-white/70 border-slate-100" : "bg-white/70 border-slate-100/50"
      )}>
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 md:h-20 flex items-center justify-between">
          <div className="flex items-center gap-2 md:gap-3 cursor-tree-hover group" onClick={reset}>
            <div className="p-1.5 md:p-2 bg-emerald-500 rounded-lg md:rounded-xl shadow-lg shadow-emerald-500/20 shrink-0 group-hover:scale-110 transition-transform">
              <Leaf className="text-white" size={20} />
            </div>
            <span className="font-display font-bold text-xl md:text-2xl tracking-tight truncate text-slate-900">CarbonBuddy <span className="text-emerald-500">AI</span></span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-[10px] font-bold uppercase tracking-[0.2em]">
            <a href="#" className="px-5 py-2 rounded-full border border-emerald-500/30 text-emerald-600 hover:bg-emerald-500 hover:text-white transition-all bg-emerald-500/5 cursor-tree-hover">Methodology</a>
            <a href="#" className="px-5 py-2 rounded-full border border-emerald-500/30 text-emerald-600 hover:bg-emerald-500 hover:text-white transition-all bg-emerald-500/5 cursor-tree-hover">Coach Index</a>
            <a href="#" className="px-5 py-2 rounded-full border border-emerald-500/30 text-emerald-600 hover:bg-emerald-500 hover:text-white transition-all bg-emerald-500/5 cursor-tree-hover">Global Impact</a>
          </div>
          <div className="flex items-center gap-3 md:gap-6">
            {view === 'results' && (
              <button 
                onClick={reset}
                className="flex items-center gap-2 text-xs md:text-sm font-bold text-slate-900 hover:text-emerald-600 transition-colors active:scale-95 bg-white px-4 py-2 rounded-full border border-slate-100 shadow-sm cursor-tree-hover"
              >
                <RefreshCcw size={14} /> <span className="hidden sm:inline">New Diagnostic</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      <main className="flex-1 pt-20 md:pt-28 px-4 md:px-6 relative z-10">
        <AnimatePresence mode="wait">
          {isLoading && (
            <motion.div 
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[200] bg-slate-950 flex flex-col items-center justify-center text-center p-6 overflow-hidden"
            >
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(40)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute bg-emerald-500/10 rounded-full blur-xl"
                    style={{ 
                      width: Math.random() * 200 + 100 + 'px', 
                      height: Math.random() * 200 + 100 + 'px',
                      left: Math.random() * 100 + '%',
                      top: Math.random() * 100 + '%'
                    }}
                    animate={{ 
                      scale: [1, 1.5, 1],
                      opacity: [0.1, 0.3, 0.1],
                      x: [0, (Math.random() - 0.5) * 100, 0],
                      y: [0, (Math.random() - 0.5) * 100, 0]
                    }}
                    transition={{ duration: 5 + Math.random() * 5, repeat: Infinity }}
                  />
                ))}
              </div>
              
              <div className="relative z-10 w-full max-w-lg">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                  className="w-32 h-32 md:w-40 md:h-40 border-t-2 border-emerald-500 border-r-2 border-r-emerald-500/30 border-b-2 border-b-transparent border-l-2 border-l-transparent rounded-full flex items-center justify-center mb-12 mx-auto relative"
                >
                  <motion.div 
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-24 h-24 bg-emerald-500/10 rounded-full flex items-center justify-center border border-emerald-500/20"
                  >
                    <Leaf className="text-emerald-400" size={32} />
                  </motion.div>
                </motion.div>

                <h2 className="text-4xl md:text-6xl font-display font-bold text-white mb-8 tracking-tighter">
                  Analyzing <span className="text-emerald-500">Profiles.</span>
                </h2>

                <div className="space-y-6">
                  {[
                    { label: "Scanning transport habits", delay: 0 },
                    { label: "Calculating lifestyle deltas", delay: 0.8 },
                    { label: "Identifying net-zero paths", delay: 1.6 }
                  ].map((stage, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: stage.delay }}
                      className="flex items-center gap-4 text-left"
                    >
                      <div className="w-5 h-5 rounded border border-emerald-500/30 flex items-center justify-center">
                        <motion.div 
                          className="w-2 h-2 bg-emerald-500 rounded-sm"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: [0, 1] }}
                          transition={{ delay: stage.delay + 0.3 }}
                        />
                      </div>
                      <span className="text-xs md:text-sm font-mono text-emerald-100/60 uppercase tracking-[0.2em]">{stage.label}</span>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-12 h-1 bg-slate-900 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.5)]"
                    initial={{ width: '0%' }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 2.5, ease: "easeInOut" }}
                  />
                </div>
              </div>
            </motion.div>
          )}

          {view === 'landing' && !isLoading && (
            <motion.div 
              key="landing"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-6xl mx-auto text-center py-6 md:py-20 flex flex-col items-center"
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="inline-flex items-center gap-2 px-4 md:px-6 py-2 bg-slate-900 text-white rounded-full text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] mb-6 md:mb-12 shadow-xl shadow-slate-900/20"
              >
                <Sparkles size={12} className="text-emerald-400" /> Introducing: Impact Diagnostic 2.0
              </motion.div>

              <h1 className="text-4xl sm:text-6xl md:text-[7.5rem] font-display font-bold leading-[1.1] md:leading-[0.85] mb-6 md:mb-12 tracking-tighter text-slate-900">
                Meet your persona-driven <br className="hidden md:block" />
                <span className="text-emerald-500 italic block mt-2 md:mt-0">Climate Coach.</span>
              </h1>

              <p className="text-lg md:text-2xl text-slate-500 max-w-3xl mx-auto mb-10 md:mb-20 leading-relaxed font-medium">
                We've moved beyond simple tracking. CarbonBuddy AI uses life-cycle analysis to find the <span className="text-slate-900 font-bold decoration-emerald-500/50 underline underline-offset-8">three unique shifts</span> that will define your sustainable future.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 md:gap-8 mb-16 md:mb-40 w-full px-4 sm:px-0">
                <motion.button 
                  whileHover={{ scale: 1.02, y: -4 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={startAssessment}
                  className="w-full sm:w-auto px-10 md:px-16 py-6 md:py-8 bg-emerald-500 text-slate-950 rounded-2xl md:rounded-[2.5rem] text-xl md:text-2xl font-bold shadow-[0_32px_64px_-16px_rgba(16,185,129,0.4)] hover:bg-emerald-400 transition-all flex items-center justify-center gap-4 group active:scale-95 cursor-tree-hover"
                >
                  Start Diagnostic <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
                </motion.button>
              </div>

              {/* Bento-style Features Preview */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-6 text-left w-full px-4 sm:px-0 pb-20">
                <div className="md:col-span-2 p-8 md:p-12 bg-white border border-slate-100 rounded-3xl md:rounded-[3rem] shadow-sm hover:shadow-2xl hover:bg-slate-50 transition-all group ring-1 ring-slate-100">
                  <div className="p-3 md:p-4 bg-emerald-500/10 text-emerald-600 rounded-2xl inline-block mb-6 md:mb-8 group-hover:scale-110 transition-transform">
                    <Sparkles size={24} />
                  </div>
                  <h3 className="text-2xl md:text-4xl font-bold mb-3 md:mb-4 font-display text-slate-900">Deep Insights.</h3>
                  <p className="text-sm md:text-xl text-slate-500 leading-relaxed font-medium italic">"Our AI doesn't just calculate; it interprets. Discover the 'Why' behind your footprint peaks with contextual advice that fits your lifestyle."</p>
                </div>
                <div className="p-8 md:p-12 bg-slate-900 text-white rounded-3xl md:rounded-[3rem] shadow-2xl flex flex-col justify-between hover:scale-[1.02] transition-transform">
                  <TrendingDown size={32} className="text-emerald-400 mb-6 md:mb-8" />
                  <h3 className="text-xl md:text-3xl font-bold font-display leading-tight mb-4">Road to Zero.</h3>
                  <p className="text-slate-400 text-xs md:text-base font-medium">Visual projections that show you exactly how close you are to climate targets.</p>
                </div>
                <div className="p-8 md:p-12 bg-white border border-slate-100 rounded-3xl md:rounded-[3rem] shadow-sm hover:shadow-xl transition-shadow ring-1 ring-slate-100/50 flex flex-col justify-between">
                   <ShieldCheck size={32} className="text-blue-500 mb-6 md:mb-8" />
                   <h3 className="text-xl md:text-3xl font-bold font-display leading-tight mb-4">Smart Logic.</h3>
                   <p className="text-slate-500 text-xs md:text-base font-medium">Verified emission factors powered by worldwide climate databases.</p>
                </div>
              </div>

              {/* Did you know section */}
              <div className="w-full mt-20 md:mt-32 max-w-5xl mx-auto px-4">
                <div className="bg-emerald-950 text-white rounded-[2.5rem] p-8 md:p-16 flex flex-col items-center text-center relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                    <div className="absolute -top-24 -left-24 w-64 h-64 bg-emerald-400 rounded-full blur-3xl" />
                    <div className="absolute bottom-12 right-12 w-96 h-96 bg-emerald-500 rounded-full blur-3xl" />
                  </div>
                  
                  <div className="relative z-10 w-full">
                    <span className="text-[10px] md:text-xs font-bold uppercase tracking-[0.3em] text-emerald-400 mb-6 md:mb-8 block">Educational Insight</span>
                    <h2 className="text-3xl md:text-5xl font-display font-bold mb-8 md:mb-12">Did you know?</h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
                      <div className="flex flex-col gap-4 text-left p-6 bg-white/5 rounded-3xl border border-white/10">
                        <div className="text-emerald-400 font-bold text-lg md:text-xl">One steak = 3,000 liters of water</div>
                        <p className="text-sm md:text-base text-emerald-100/70 leading-relaxed font-medium">
                          Producing just 1kg of beef emits approximately 60kg of CO2 and requires thousands of liters of water. Skipping meat just once a week makes a massive dent.
                        </p>
                      </div>
                      <div className="flex flex-col gap-4 text-left p-6 bg-white/5 rounded-3xl border border-white/10">
                        <div className="text-emerald-400 font-bold text-lg md:text-xl">The 100-Company Rule</div>
                        <p className="text-sm md:text-base text-emerald-100/70 leading-relaxed font-medium">
                          Just 100 companies have been responsible for 71% of global greenhouse emissions since 1988. Collective action and voting with your wallet works.
                        </p>
                      </div>
                    </div>
                    
                    <div className="mt-12 md:mt-16 pt-8 border-t border-white/10">
                      <p className="text-xs md:text-sm text-emerald-200/50 italic">Source: IPCC Special Report 2024 & World Wildlife Fund Statistics</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'assessment' && (
            <div key="assessment" className="max-w-4xl mx-auto py-10 md:py-20">
              <div className="mb-8 md:mb-12 text-center px-4">
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 font-display mb-3 md:mb-4">The Impact Diagnostic</h2>
                <p className="text-sm md:text-base text-slate-500 italic">"I'll need a few snapshots of your lifestyle to build your custom roadmap."</p>
              </div>
              <AssessmentForm onComplete={handleAssessmentComplete} />
            </div>
          )}

          {view === 'results' && results && assessment && (
            <motion.div 
              key="results"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="max-w-7xl mx-auto grid grid-cols-1 xl:grid-cols-4 gap-8 md:gap-12 pb-20"
            >
              <div className="xl:col-span-3">
                <Dashboard results={results} />
              </div>
              
              <aside className="space-y-8">
                <DocumentScanner onDataExtracted={(data) => console.log('Extracted:', data)} />
                <div className="bg-slate-900 p-8 rounded-[2rem] md:rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
                  <div className="absolute -top-12 -right-12 w-48 h-48 bg-emerald-500/20 rounded-full blur-3xl" />
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
                      <Zap size={20} />
                    </div>
                    <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Next Frontier</span>
                  </div>
                  <h4 className="text-2xl font-bold mb-4 font-display">Beyond the Top 3</h4>
                  <p className="text-sm text-slate-400 leading-relaxed mb-8">
                    Once you've mastered your priority actions, I recommend exploring your <span className="text-white font-bold">{results.secondaryActions[0]?.category}</span> impact.
                  </p>
                  <button className="w-full py-4 bg-emerald-500 text-slate-950 rounded-2xl font-bold text-sm shadow-lg hover:bg-emerald-400 transition-all active:scale-95 cursor-tree-hover">
                    View Secondaries
                  </button>
                </div>
                
                <div className="p-8 bg-white border border-slate-100 rounded-[2rem] md:rounded-[2.5rem] shadow-sm">
                  <h4 className="text-lg font-bold text-slate-900 mb-4 font-display">Coach Verification</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    This analysis is based on global averages and your self-reported data. For accuracy, consider syncing your utility bills.
                  </p>
                </div>
              </aside>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer responsiveness */}
      <footer className={cn(
        "mt-12 md:mt-24 border-t transition-colors duration-500 pb-12 pt-12 md:pb-16 md:pt-16 px-6",
        view === 'landing' ? "bg-white border-slate-100" : "bg-white border-slate-100"
      )}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8 text-slate-500 text-sm font-medium">
          <div className="flex items-center gap-3 cursor-tree-hover" onClick={reset}>
            <div className="p-1.5 bg-emerald-500 rounded-lg">
              <Leaf size={16} className="text-white" />
            </div>
            <span className="font-display font-bold tracking-tight text-lg cursor-pointer text-slate-900">CarbonBuddy AI</span>
          </div>
          <p className="text-center md:text-left">© 2026 ClimateOS. All rights reserved.</p>
          <div className="flex flex-wrap justify-center gap-8 md:gap-12 uppercase tracking-widest text-[10px]">
            <a href="#" className="hover:text-slate-900 transition-colors">Security</a>
            <a href="#" className="hover:text-slate-900 transition-colors">Privacy</a>
            <a href="#" className="hover:text-slate-900 transition-colors flex items-center gap-1.5"><Github size={14} /> GitHub</a>
          </div>
        </div>
      </footer>

      {/* Floating AI Coach Container - Responsive adjustments */}
      {view === 'results' && assessment && (
        <div className="fixed bottom-6 right-6 md:bottom-10 md:right-10 z-[100]">
          <AnimatePresence>
            {showCoach && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="mb-4 md:mb-6 drop-shadow-2xl fixed inset-4 md:inset-auto md:relative md:bottom-auto md:right-auto md:w-auto"
              >
                <div className="md:w-lg h-[80vh] md:h-[600px]">
                  <AICoach assessment={assessment} onClose={() => setShowCoach(false)} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <div className="flex items-center gap-3 md:gap-4 bg-slate-900 p-1.5 md:p-2 rounded-full shadow-2xl shadow-slate-900/40 cursor-tree-hover">
            <button 
              onClick={() => setShowCoach(!showCoach)}
              className={cn(
                "w-12 h-12 md:w-14 md:h-14 rounded-full flex items-center justify-center transition-all active:scale-90",
                showCoach ? "bg-white text-slate-900" : "bg-emerald-500 text-white"
              )}
            >
              {showCoach ? <X size={20} className="md:w-6 md:h-6" /> : <MessageSquare size={20} className="md:w-6 md:h-6" />}
            </button>
            {!showCoach && (
              <div className="pr-5 md:pr-6 pl-1 md:pl-2 hidden sm:block">
                <span className="text-[10px] md:text-xs text-white font-bold uppercase tracking-widest">Ask your Coach</span>
                <div className="flex items-center gap-1.5 md:gap-2">
                  <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-emerald-400 rounded-full animate-pulse" />
                  <span className="text-[9px] md:text-[10px] text-slate-400 font-medium">Lilo is ready to help</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
